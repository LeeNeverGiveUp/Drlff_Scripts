extern "C" void Cuda_Cuda_GetCompileSettings(cuda_shared_data* sdata);
