#!/usr/bin/env python

# John A. Wendel    01/2012
# converter from 2001 reax ffield format to reax 2012 ffield format

import sys,string

def cap(x):
   if len(x) == 2:
      return('%s%s' % (string.upper(x[0]),string.lower(x[1])))
   elif len(x) == 1:
      return('%s' % string.upper(x[0]))
   else: 
      print 'Error in cap(x)'

args = sys.argv[1:]

if len(args) != 2 and len(args) != 3: 
   print '\nUsage: reaxconv_old2new.py ffield_old ffield_new [optional name of params file in old format]\n'
   print 'This script requires two arguments: a reax 2001 ffield file & the filename of the 2012 ffield file to be created\n'
   print 'If you want to include params data from the old format, give the name of the params file in old format\n'
   sys.exit()
#   print_help()

# input, output, and parameter file names

input_file = args[0]
output_file = args[1]
params_file = ''
if len(args) == 3:
   params_file = args[2]
   
# read in the input file by lines
   
f = open(input_file,'r')
L = f.readlines()
f.close()

# set the keywords for the various fields

generalkeys = ['overcoord1','overcoord2','valangconj1','tripbond1','tripbond2','nu1','undercoord1','tripbond3','undercoord2', \
               'undercoord3','tripbond4','lowertaper','uppertaper','nu2','valunder','valanglp','valang1','valang2','nu3','dblbndang1', \
               'dblbndang2','dblbndang3','nu4','torbo','torover1','torover2','nu5','conj','vdwshield','cutoffbo','valangconj2','overcoord3', \
               'overcoord4','vallp','nu6','nu7','nu8','nu9','valangconj3']

atomkeys = ['rosigma','val','am','rvdw','dij','gamma','ropi','vale','alfa','gammaw','valangle','povun5','nu1','chieem','etaeem', \
            'nu2','ropipi','plp2','heatinc','pboc4','pboc3','pboc5','nu3','nu4','povun2','pval3','nu5','valboc','pval5','nu6','nu7','nu8']
            
bondkeys = ['desigma','depi','depipi','pbe1','pbo5','13corr','pbo6','povun1','pbe2','pbo3','pbo4','nu1','pbo1','pbo2','nu2','nu3']

offdiagkeys = ['dij','rvdw','alfa','rosigma','ropi','ropipi']

anglekeys = ['thetao','pval1','pval2','pcoa1','pval7','ppen1','pval4']

torsionkeys = ['v1','v2','v3','ptor1','pcot1','nu1','nu2']

hbondkeys = ['rhb','phb1','phb2','phb3']

# setup dictionaries to access variable # (in ffield) by name

generalkeydict = {}
atomkeydict = {}
bondkeydict = {}
offdiagkeydict = {}
anglekeydict = {}
torsionkeydict = {}
hbondkeydict = {}

for ii in range(len(generalkeys)):
   generalkeydict[generalkeys[ii]] = ii + 1
   
for ii in range(len(atomkeys)):
   atomkeydict[atomkeys[ii]] = ii + 1
   
for ii in range(len(bondkeys)):
   bondkeydict[bondkeys[ii]] = ii + 1

for ii in range(len(offdiagkeys)):
   offdiagkeydict[offdiagkeys[ii]] = ii + 1
   
for ii in range(len(anglekeys)):
   anglekeydict[anglekeys[ii]] = ii + 1
   
for ii in range(len(torsionkeys)):
   torsionkeydict[torsionkeys[ii]] = ii + 1
   
for ii in range(len(hbondkeys)):
   hbondkeydict[hbondkeys[ii]] = ii + 1


f = open(output_file,'w')

f.write('2012 reactive MD force field file\n')
f.write('version 0.1\n')

lcount = 0    # keep track of the position in the old ffield file by the line count

for ii in range(len(L)):
   L[ii] = string.split(L[ii])


generalcomments = ['#Overcoordination parameter', \
                   '#Overcoordination parameter', \
                   '#Valency angle conjugation parameter', \
                   '#Triple bond stabilisation parameter', \
                   '#Triple bond stabilisation parameter', \
                   '#C2-correction', \
                   '#Undercoordination parameter', \
                   '#Triple bond stabilisation parameter', \
                   '#Undercoordination parameter', \
                   '#Undercoordination parameter', \
                   '#Triple bond stabilization energy', \
                   '#Lower Taper-radius', \
                   '#Upper Taper-radius', \
                   '#Not used', \
                   '#Valency undercoordination', \
                   '#Valency angle/lone pair parameter', \
                   '#Valency angle', \
                   '#Valency angle parameter', \
                   '#Not used', \
                   '#Double bond/angle parameter', \
                   '#Double bond/angle parameter: overcoord', \
                   '#Double bond/angle parameter: overcoord', \
                   '#Not used', \
                   '#Torsion/BO parameter', \
                   '#Torsion overcoordination', \
                   '#Torsion overcoordination', \
                   '#Conjugation 0 (not used)', \
                   '#Conjugation', \
                   '#vdWaals shielding', \
                   '#Cutoff for bond order (*100)', \
                   '#Valency angle conjugation parameter', \
                   '#Overcoordination parameter', \
                   '#Overcoordination parameter', \
                   '#Valency/lone pair parameter', \
                   '#Not used', \
                   '#Not used', \
                   '#Molecular energy (not used)', \
                   '#Molecular energy (not used)', \
                   '#Valency angle conjugation parameter']


ngeneral = 0 

# keep reading the old ffield file until we get the number of general parameters (currently 39)

while ngeneral == 0:
   try:
      ngeneral = int(L[lcount][0])
   except:
      lcount += 1

lcount += 1

# write out the value of the general variables 

for ii in range(ngeneral):
   f.write('general  %-12s %9.4f  %s\n' % (generalkeys[ii],float(L[lcount][0]),generalcomments[ii]))
   lcount += 1
      
natoms = int(L[lcount][0])   # read the number of atoms at the head of the atom section
lcount += 4       # skip the comment lines in the atoms section
atomchar = {}     # dictionary relating atom number (keys) to atom character (values)
atomchar[0] = 'X' # set 'X' as 0

# hold single chars (for atoms) or tuples of chars for variable types in order they appear in old ffield in following lists

oldatoms = []
oldbonds = []
oldoffdiags = []
oldangles = []
oldtorsions = []
oldhbonds = []

# loop the variable blocks (atoms, bonds, angles, etc.) and write out the data in new format

for ii in range(natoms):
   atomname = L[lcount][0]
   atomchar[ii + 1] = atomname
   
   for jj in range(8):   # 32 elements in atomkeys
      f.write('atom  %-2s  %-10s  %9.4f\n' % (atomname,atomkeys[jj],float(L[lcount][jj + 1])))   # need +1 here because extra field for element on this line
   lcount += 1                                                                                       
        
   for jj in range(8):
      f.write('atom  %-2s  %-10s  %9.4f\n' % (atomname,atomkeys[jj + 8],float(L[lcount][jj])))
   lcount += 1
   
   for jj in range(8):
      f.write('atom  %-2s  %-10s  %9.4f\n' % (atomname,atomkeys[jj + 16],float(L[lcount][jj])))
   lcount += 1
         
   for jj in range(8):
      f.write('atom  %-2s  %-10s  %9.4f\n' % (atomname,atomkeys[jj + 24],float(L[lcount][jj])))
   lcount += 1
      
nbonds = int(L[lcount][0])
      
lcount += 2       # skip the two comment lines for bonds in old format
   
for ii in range(nbonds):
   atom1 = atomchar[int(L[lcount][0])]
   atom2 = atomchar[int(L[lcount][1])]   
   oldbonds.append((atom1,atom2))
   
   for jj in range(8):
      f.write('bond  %-2s  %-2s  %-10s  %9.4f\n' % (atom1,atom2,bondkeys[jj],float(L[lcount][jj + 2]))) # offset 2 for 2 atom #'s on line
   lcount += 1
   for jj in range(8):
      f.write('bond  %-2s  %-2s  %-10s  %9.4f\n' % (atom1,atom2,bondkeys[jj + 8],float(L[lcount][jj])))
   lcount += 1
         
noffdiags = int(L[lcount][0])
lcount += 1
   
for ii in range(noffdiags):
   atom1 = atomchar[int(L[lcount][0])]
   atom2 = atomchar[int(L[lcount][1])] 
   oldoffdiags.append((atom1,atom2))
     
   for jj in range(len(offdiagkeys)):
      f.write('offdiag  %-2s  %-2s  %-10s  %9.4f\n' % (atom1,atom2,offdiagkeys[jj],float(L[lcount][jj + 2])))
   lcount += 1   

nangles = int(L[lcount][0])
lcount += 1
   
for ii in range(nangles):
   atom1 = atomchar[int(L[lcount][0])]   
   atom2 = atomchar[int(L[lcount][1])]  
   atom3 = atomchar[int(L[lcount][2])]
   oldangles.append((atom1,atom2,atom3))  # make a tuple holding the angle name (e.g. ('C','C','H')) and store it
    
   for jj in range(len(anglekeys)):       # for all the angle parameters - write out in new format
      f.write('angle  %-2s  %-2s  %-2s  %-10s  %9.4f\n' % (atom1,atom2,atom3,anglekeys[jj],float(L[lcount][jj + 3])))
   lcount += 1
      
ntorsions = int(L[lcount][0])
lcount += 1
   
for ii in range(ntorsions):
   atom1 = atomchar[int(L[lcount][0])]
   atom2 = atomchar[int(L[lcount][1])]  
   atom3 = atomchar[int(L[lcount][2])]
   atom4 = atomchar[int(L[lcount][3])]
   oldtorsions.append((atom1,atom2,atom3,atom4))
   
   for jj in range(len(torsionkeys)):
      f.write('torsion  %-2s  %-2s  %-2s  %-2s  %-10s  %9.4f\n' % (atom1,atom2,atom3,atom4,torsionkeys[jj],float(L[lcount][jj + 4])))  
   lcount += 1

skiphbonds = 0

# hbonds are optional - if there are no hbonds in the old ffield file, trying to read further will fail, otherwise process nhbonds
       
try:
   nhbonds = int(L[lcount][0])
except:
   skiphbonds = 1
   
lcount += 1 

if skiphbonds == 0:
   for ii in range(nhbonds):
      atom1 = atomchar[int(L[lcount][0])]
      atom2 = atomchar[int(L[lcount][1])]  
      atom3 = atomchar[int(L[lcount][2])]
      oldhbonds.append((atom1,atom2,atom3,atom4))
   
      for jj in range(len(hbondkeys)):
         f.write('hbond  %-2s  %-2s  %-2s  %-10s  %9.4f\n' % (atom1,atom2,atom3,hbondkeys[jj],float(L[lcount][jj + 3])))
      lcount += 1
          
f.close()       # close the output file written in new (2012) format  

# if there is an old style parameter file, read it in, otherwise done

if len(params_file) != 0:
   f = open(params_file,'r')
   P = f.readlines()
   f.close()  
else:
   sys.exit(0)       

# remove the comments and split the individual lines on white space

for ii in range(len(P)):
   remarkposn = string.find(P[ii],'!')
   if remarkposn != -1:
      P[ii] = P[ii][:remarkposn]
      
for ii in range(len(P)):
   P[ii] = string.split(P[ii])
   
   if len(P[ii]) != 6:   # if the parameter line is not formatted correctly, delete it
      P[ii] = ''
      continue


# make a quick dictionary here relating variable type from old ffield (e.g. 2 is atom, 3 is bond, etc.) to name

types = ['general','atom','bond','offdiag','angle','torsion','hbond']
typedict = {}
for ii in range(len(types)):
   typedict[ii + 1] = types[ii]

oldparams = {}

params = {}  # hold the parameters as a dictionary of tuples which are (variable type,char or tuple of chars,name of variable subtype)
             # for example ('bond',('C','H'),'depi') or ('general','overcoord1',1) or ('atom','C','povun5') or ('angle',('C','C','H'),'thetao')
             # these keys reference a list of three floats, the increment, upper(max) value, and lowest(min) value
             # for example [2,170,30] 

Plist = []   # in order to be compatible with the old format, in which people entered long iterative schemes for each variable,
             # this List holds the params key from above but multiple times (each incidence is appended to the list), not like params, which is a dictionary
             
values = []  # holds list of 3-item lists for the referenced values from above, but multiple times  
             # Plist[] and values[] are connected by a common index

for ii in range(len(P)):
   if len(P[ii]) == 0: continue   # skip empty lines
   
   vartype = typedict[int(P[ii][0])]  # get the variable type (general, atom, bond, etc.)
   
   if string.find(vartype,'general') == 0:                       # recognized as general
      tmpkey = (vartype,generalkeys[int(P[ii][1]) - 1],1)        # make the key as a tuple (general variables always get a 1 in the last slot of the tuple of 3 items)
      data = [float(P[ii][3]),float(P[ii][4]),float(P[ii][5])]   # list of 3 data points (increment, max, min)
      params[tmpkey] = data                                      # set the dictionary entry
      Plist.append(tmpkey)                                       # append this entry to Plist (allow multiple entries of the same variable since it is a list)
      values.append(data)                                        # carry values along corollary to Plist
   elif string.find(vartype,'atom') == 0:
      tmpkey = (vartype,atomchar[int(P[ii][1])],atomkeys[int(P[ii][2]) - 1])  # need -1 here since variables start from 1 but are held in an array (from 0)
      data = [float(P[ii][3]),float(P[ii][4]),float(P[ii][5])]
      params[tmpkey] = data
      Plist.append(tmpkey)
      values.append(data)
   elif string.find(vartype,'bond') == 0:
      tmpkey = (vartype,oldbonds[int(P[ii][1]) - 1],bondkeys[int(P[ii][2]) - 1])
      data = [float(P[ii][3]),float(P[ii][4]),float(P[ii][5])]
      params[tmpkey] = data
      Plist.append(tmpkey)
      values.append(data)
   elif string.find(vartype,'offdiag') == 0:
      tmpkey = (vartype,oldoffdiags[int(P[ii][1]) - 1],offdiagkeys[int(P[ii][2]) - 1])
      data = [float(P[ii][3]),float(P[ii][4]),float(P[ii][5])]
      params[tmpkey] = data
      Plist.append(tmpkey)
      values.append(data)
   elif string.find(vartype,'angle') == 0:
      tmpkey = (vartype,oldangles[int(P[ii][1]) - 1],anglekeys[int(P[ii][2]) - 1])
      data = [float(P[ii][3]),float(P[ii][4]),float(P[ii][5])]
      params[tmpkey] = data
      Plist.append(tmpkey)
      values.append(data)
   elif string.find(vartype,'torsion') == 0:
      tmpkey = (vartype,oldtorsions[int(P[ii][1]) - 1],torsionkeys[int(P[ii][2]) - 1])
      data = [float(P[ii][3]),float(P[ii][4]),float(P[ii][5])]
      params[tmpkey] = data
      Plist.append(tmpkey)
      values.append(data)
   elif string.find(vartype,'hbond') == 0:
      tmpkey = (vartype,oldhbonds[int(P[ii][1]) - 1],hbondkeys[int(P[ii][2]) - 1])
      data = [float(P[ii][3]),float(P[ii][4]),float(P[ii][5])]
      params[tmpkey] = data
      Plist.append(tmpkey)
      values.append(data)
   else: 
      print 'Unknown data type specified in params: %s',vartype


# read the created new 2012 forcefield back in
 
f = open(output_file,'r')
L = f.readlines()
f.close()

lineno = {}  # lineno is a dictionary filled with tuples similar to those from P & Plist giving the (main variable,char or tuple of chars,specific variable name)
             # that points to the line number in the newly created forcefield file
             # for example ('bond',('C','H'),'depi') or ('general','overcoord1',1) or ('atom','C','povun5') or ('angle',('C','C','H'),'thetao')
             # so a variable can be pinpointed by exact line number to have optimization information appended

for ii in range(len(L)):
   L[ii] = string.split(L[ii])

for ii in range(len(L)):
   if len(L[ii]) == 0: continue
   if string.find(L[ii][0],'general') == 0:
      lineno[(L[ii][0],L[ii][1],1)] = ii
   elif string.find(L[ii][0],'atom') == 0:
      lineno[(L[ii][0],L[ii][1],L[ii][2])] = ii
   elif string.find(L[ii][0],'bond') == 0:
      lineno[(L[ii][0],(L[ii][1],L[ii][2]),L[ii][3])] = ii
   elif string.find(L[ii][0],'offdiag') == 0:
      lineno[(L[ii][0],(L[ii][1],L[ii][2]),L[ii][3])] = ii
   elif string.find(L[ii][0],'angle') == 0:
      lineno[(L[ii][0],(L[ii][1],L[ii][2],L[ii][3]),L[ii][4])] = ii
   elif string.find(L[ii][0],'torsion') == 0:
      lineno[(L[ii][0],(L[ii][1],L[ii][2],L[ii][3],L[ii][4]),L[ii][5])] = ii
   elif string.find(L[ii][0],'hbond') == 0:
      lineno[(L[ii][0],(L[ii][1],L[ii][2],L[ii][3]),L[ii][4])] = ii
      

paramkeys = params.keys()   # list of tuple keys to params

# read the new forcefield file in again but don't split it this time - these are, for all practical purposes, small files, so just read it again

f = open(output_file,'r')
L = f.readlines()
f.close()

for ii in range(len(params)):

   position = lineno[paramkeys[ii]]  # this is the line number in the new forcefield that parameters are going to be added to
   
   if string.find(L[position],'general') != 0:    # if its a general variable, then there are comments - handle that case separately
      L[position] = L[position][:-1]              # cut off '\n'
      L[position] = '%s %8.4f %8.4f %8.4f\n' % (L[position],params[paramkeys[ii]][0],params[paramkeys[ii]][1],params[paramkeys[ii]][2]) # append the line
   else:
      x = string.split(L[position])
      L[position] = 'general  %-12s %9.4f %8.4f %8.4f %8.4f %s\n' % (x[1],float(x[2]),params[paramkeys[ii]][0],params[paramkeys[ii]][1],params[paramkeys[ii]][2],x[3])
   
f = open(output_file,'w')
for ii in range(len(L)):
   f.write(L[ii])
f.close()

#sys.exit(0)

# EVERYTHING BELOW THIS IS TO WRITE REPEATING PARAMS FILES WITH THE NEW PARAMETERS

# this code is documented in the new2old reader

f = open(output_file,'r')
L = f.readlines()
f.close()

for ii in range(len(L)):
   L[ii] = string.split(L[ii])
   
# cut and paste from new2old

# instantiate the dictionaries
               
generals = {}
atoms = {}
bonds = {}
offdiags = {}
angles = {}
torsions = {}
hbonds = {}

for ii in range(len(generalkeys)):
   generals[generalkeys[ii]] = 0.0

atomlabels = []
atno = {}
atno['X'] = 0
atomcount = 1

for ii in range(len(L)):

   if len(L[ii]) == 0: continue               # skip blank lines

   if string.find(L[ii][0],'general') == 0:
      if generals.has_key(L[ii][1]) == 0:
         print 'Tried to set unknown general parameter: %s on line %d of input' % (L[ii][1],ii)
      else:
         generals[L[ii][1]] = float(L[ii][2])
         
   elif string.find(L[ii][0],'atom') == 0:
      
      L[ii][1] = cap(L[ii][1])
         
      if atoms.has_key(L[ii][1]) == 0:
         atomlabels.append(L[ii][1])
         if string.find(L[ii][1],'X') != 0:
            atno[L[ii][1]] = atomcount
            atomcount += 1
         
         atoms[L[ii][1]] = {}
         for jj in range(len(atomkeys)):
            atoms[L[ii][1]][atomkeys[jj]] = 0.0
      
      if atoms[L[ii][1]].has_key(L[ii][2]) == 0:
         print 'Tried to set unknown atom parameter: %s on line %d of input' % (L[ii][2],ii)
      else:
         atoms[L[ii][1]][L[ii][2]] = float(L[ii][3])
         
   elif string.find(L[ii][0],'bond') == 0:
      bondtag = (cap(L[ii][1]),cap(L[ii][2]))     
      if bonds.has_key(bondtag) == 0:
         bonds[bondtag] = {}
         for jj in range(len(bondkeys)):
            bonds[bondtag][bondkeys[jj]] = 0.0
      
      if bonds[bondtag].has_key(L[ii][3]) == 0:
         print 'Tried to set unknown bond parameter: %s on line %d of input' % (L[ii][3],ii)
      else:
         bonds[bondtag][L[ii][3]] = float(L[ii][4])
    
   elif string.find(L[ii][0],'offdiag') == 0:
      offdiagtag = (cap(L[ii][1]),cap(L[ii][2]))
      if offdiags.has_key(offdiagtag) == 0:
         offdiags[offdiagtag] = {}
         for jj in range(len(offdiagkeys)):
            offdiags[offdiagtag][offdiagkeys[jj]] = 0.0
     
      if offdiags[offdiagtag].has_key(L[ii][3]) == 0:
         print 'Tried to set unknown offdiag parameter: %s on line %d of input' % (L[ii][3],ii)
      else:
         offdiags[offdiagtag][L[ii][3]] = float(L[ii][4])
      
   elif string.find(L[ii][0],'angle') == 0:
      angletag = (cap(L[ii][1]),cap(L[ii][2]),cap(L[ii][3]))
      if angles.has_key(angletag) == 0:
         angles[angletag] = {}
         brandnew = 1
         for jj in range(len(anglekeys)):
            angles[angletag][anglekeys[jj]] = 0.0
            
      if angles[angletag].has_key(L[ii][4]) == 0:
         print 'Tried to set unknown angle parameter: %s on line %d of input' % (L[ii][4],ii)
      else:
         angles[angletag][L[ii][4]] = float(L[ii][5])

      
   elif string.find(L[ii][0],'torsion') == 0:                  # parameter type recognized as torsion
      torsiontag = (cap(L[ii][1]),cap(L[ii][2]),cap(L[ii][3]),cap(L[ii][4]))       # make an identifier for this torsion as a tuple
      if torsions.has_key(torsiontag) == 0:                    # if this is a new torsion, declare it 
         torsions[torsiontag] = {}                             # and set it as a blank dictionary
         for jj in range(len(torsionkeys)):                    # iterate the list torsionkeys
            torsions[torsiontag][torsionkeys[jj]] = 0.0        # add the keys to the new dictionary and set them to 0.0
            
      if torsions[torsiontag].has_key(L[ii][5]) == 0:          # if the torsion parameter the user is trying to set is not a keyword
         print 'Tried to set unknown torsion parameter: %s on line %d of input' % (L[ii][5],ii)   # print a warning
      else:
         torsions[torsiontag][L[ii][5]] = float(L[ii][6])      # or just set it to the value given
         
   elif string.find(L[ii][0],'hbond') == 0:
      hbondtag = (cap(L[ii][1]),cap(L[ii][2]),cap(L[ii][3]))
      if hbonds.has_key(hbondtag) == 0:
         hbonds[hbondtag] = {}
         for jj in range(len(hbondkeys)):
            hbonds[hbondtag][hbondkeys[jj]] = 0.0
      
      if hbonds[hbondtag].has_key(L[ii][4]) == 0:
         print 'Tried to set an unknown hbond parameter: %s on line %d of input' % (L[ii][4],ii)
      else:
         hbonds[hbondtag][L[ii][4]] = float(L[ii][5])
         
   else:
      if ii !=0 and ii != 1:  # skip first two lines
         print 'Unknown paramter type %s found on line %d of input.  Ignoring.' % (L[ii][0],ii)        
            
bondlabels = bonds.keys()
bondlabels.sort()
bondno = {}
for ii in range(len(bondlabels)):
   bondno[bondlabels[ii]] = ii + 1

offdiaglabels = offdiags.keys()
offdiaglabels.sort()
offdiagno = {}
for ii in range(len(offdiaglabels)):
   offdiagno[offdiaglabels[ii]] = ii + 1

anglelabels = angles.keys()
anglelabels.sort()
angleno = {}
for ii in range(len(anglelabels)):
   angleno[anglelabels[ii]] = ii + 1
   
torsionlabels = torsions.keys()
torsionlabels.sort()
torsionno = {}
for ii in range(len(torsionlabels)):
   torsionno[torsionlabels[ii]] = ii + 1

hbondlabels = hbonds.keys()
hbondlabels.sort()
hbondno = {}
for ii in range(len(hbondlabels)):
   hbondno[hbondlabels[ii]] = ii + 1

parms = []

typedict = {}

types = ['general','atom','bond','offdiag','angle','torsion','hbond']

for ii in range(len(types)):
   typedict[types[ii]] = ii + 1

for ii in range(len(Plist)):
   if len(Plist[ii]) == 0: continue
   
   if typedict.has_key(Plist[ii][0]) == 0: continue
   
   if string.find(Plist[ii][0],'general') == 0:
      parms.append([1,generalkeydict[Plist[ii][1]],1,values[ii][0],values[ii][1],values[ii][2]])
         
   elif string.find(Plist[ii][0],'atom') == 0:
      parms.append([2,atno[Plist[ii][1]],atomkeydict[Plist[ii][2]],values[ii][0],values[ii][1],values[ii][2]])
         
   elif string.find(Plist[ii][0],'bond') == 0:
      parms.append([3,bondno[Plist[ii][1]],bondkeydict[Plist[ii][2]],values[ii][0],values[ii][1],values[ii][2]])
         
   elif string.find(Plist[ii][0],'offdiag') == 0:
      parms.append([4,offdiagno[Plist[ii][1]],offdiagkeydict[Plist[ii][2]],values[ii][0],values[ii][1],values[ii][2]])
         
   elif string.find(Plist[ii][0],'angle') == 0:
      parms.append([5,angleno[Plist[ii][1]],anglekeydict[Plist[ii][2]],values[ii][0],values[ii][1],values[ii][2]])
         
   elif string.find(Plist[ii][0],'torsion') == 0:
      parms.append([6,torsionno[Plist[ii][1]],torsionkeydict[Plist[ii][2]],values[ii][0],values[ii][1],values[ii][2]])
         
   elif string.find(Plist[ii][0],'hbond') == 0:
      parms.append([7,hbondno[Plist[ii][1]],hbondkeydict[Plist[ii][2]],values[ii][0],values[ii][1],values[ii][2]])
         
   else:
      print 'Unknown type encountered when scanning for optimization parameters.'

f = open('params.output','w')
   
for ii in range(len(parms)):
   f.write('%3d%3d%3d%9.4f%9.4f%9.4f\n' % (parms[ii][0],parms[ii][1],parms[ii][2],parms[ii][3],parms[ii][4],parms[ii][5]))
   
f.close()
